# Tick-Tock Animation

Simple pure-CSS animation made just for fun.

 
## Demo

http://goliney.github.io/tick-tock/

![Demo](./demo.gif?raw-true "Demo Image")