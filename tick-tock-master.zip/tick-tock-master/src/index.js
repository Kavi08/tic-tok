// SCSS
import './scss/main.scss';

// JS
import './js/main.js';